package com.example.myapplication.model

abstract class Race(val name: String, val bonuses: Map<String, Int>)