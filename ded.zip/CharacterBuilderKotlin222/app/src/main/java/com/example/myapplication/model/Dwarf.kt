package com.example.myapplication.model

class Dwarf : Race("Anão", mapOf(
    "Constituição" to 2
))