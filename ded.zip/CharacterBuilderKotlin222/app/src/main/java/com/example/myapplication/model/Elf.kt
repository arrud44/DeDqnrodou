package com.example.myapplication.model

class Elf : Race("Elfo", mapOf(
    "Destreza" to 2
))