package com.example.myapplication.model

class Halfling : Race("Halfling", mapOf(
    "Destreza" to 2
))