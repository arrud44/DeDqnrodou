package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF4CAF50)
val PurpleGrey80 = Color(0xFF8BC34A)
val Pink80 = Color(0xFFCDDC39)

val Purple40 = Color(0xFFFFC107)
val PurpleGrey40 = Color(0xFFFF9800)
val Pink40 = Color(0xFFFF5722)